SESSION_NAME: str = ''
SESSION_EMAIL: str = ''
SESSION_LOGGED_IN: bool = False